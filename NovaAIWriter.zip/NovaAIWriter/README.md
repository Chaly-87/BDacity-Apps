# NovaAI Writer - Aplicação Android

## Descrição
NovaAI Writer é uma aplicação Android completa para geração inteligente de conteúdo usando múltiplas IAs. A aplicação permite criar ebooks, apresentações e documentos com diferentes estilos de escrita.

## Funcionalidades

### 🔥 Funcionalidades Principais
- **Gerador de Ebooks**: Cria ebooks estruturados com capítulos automáticos
- **Criador de Apresentações**: Gera apresentações com slides organizados
- **Gerador de Documentos**: Produz resumos, relatórios e guias formatados
- **Personalização**: 4 estilos disponíveis (Académico, Criativo, Simples, Técnico)
- **Múltiplas IAs**: Integração com ChatGPT, Claude, Gemini e Llama
- **Exportação**: Suporte para PDF, DOCX e TXT

### 💎 Sistema Premium
- **Utilizadores Gratuitos**: 3 gerações por dia, conteúdo limitado, apenas exportação TXT
- **Utilizadores Premium**: 50 gerações por dia, conteúdo extenso, todas as exportações

### 🎨 Interface
- Design moderno e minimalista
- Fundo branco com detalhes em azul (inspirado no Gamma.ai)
- Menu inferior com navegação intuitiva
- Interface responsiva usando Jetpack Compose

## Arquitetura Técnica

### 📱 Tecnologias Utilizadas
- **Linguagem**: Kotlin
- **UI Framework**: Jetpack Compose
- **Arquitetura**: MVVM (Model-View-ViewModel)
- **Base de Dados**: Room Database
- **Rede**: Retrofit + OkHttp
- **Exportação PDF**: iText 7
- **JSON**: Gson

### 🏗️ Estrutura do Projeto
```
app/src/main/java/com/novaai/writer/
├── ui/
│   ├── screens/          # Telas da aplicação
│   ├── components/       # Componentes reutilizáveis
│   └── theme/           # Tema e cores
├── data/
│   ├── models/          # Modelos de dados
│   ├── repository/      # Repositórios
│   ├── api/            # Interfaces de API
│   └── database/       # Entidades Room
├── viewmodel/          # ViewModels
├── generator/          # Gerador de conteúdo
├── exporter/          # Exportação de documentos
├── ai/               # Provedores de IA
├── storage/          # Gestão de armazenamento
└── premium/          # Sistema premium
```

## Como Compilar

### Pré-requisitos
- Android Studio Arctic Fox ou superior
- JDK 8 ou superior
- Android SDK API 24+ (Android 7.0)

### Passos para Compilação
1. **Abrir o Projeto**
   ```bash
   # Extrair o projeto
   unzip NovaAIWriter.zip
   
   # Abrir no Android Studio
   # File > Open > Selecionar pasta NovaAIWriter
   ```

2. **Sincronizar Dependências**
   - O Android Studio irá automaticamente sincronizar as dependências
   - Aguardar a conclusão do processo

3. **Configurar Emulador ou Dispositivo**
   - Criar um AVD (Android Virtual Device) ou
   - Conectar um dispositivo Android físico com depuração USB ativada

4. **Compilar e Executar**
   ```bash
   # Via Android Studio
   Build > Make Project
   Run > Run 'app'
   
   # Via linha de comando
   ./gradlew assembleDebug
   ```

5. **Gerar APK de Release**
   ```bash
   # APK de debug
   ./gradlew assembleDebug
   
   # APK de release (requer assinatura)
   ./gradlew assembleRelease
   ```

### Localização do APK
- **Debug**: `app/build/outputs/apk/debug/app-debug.apk`
- **Release**: `app/build/outputs/apk/release/app-release.apk`

## Configuração de APIs

### Integração com IAs Reais
Para integrar com APIs reais das IAs, editar os ficheiros:

1. **ChatGPT (OpenAI)**
   ```kotlin
   // ai/AIProvider.kt - ChatGPTProvider
   // Adicionar chave da API e endpoint real
   ```

2. **Claude (Anthropic)**
   ```kotlin
   // ai/AIProvider.kt - ClaudeProvider
   // Adicionar chave da API e endpoint real
   ```

3. **Gemini (Google)**
   ```kotlin
   // ai/AIProvider.kt - GeminiProvider
   // Adicionar chave da API e endpoint real
   ```

4. **Llama (Meta)**
   ```kotlin
   // ai/AIProvider.kt - LlamaProvider
   // Adicionar chave da API e endpoint real
   ```

## Funcionalidades Implementadas

### ✅ Completas
- [x] Interface de utilizador completa
- [x] Navegação entre telas
- [x] Geração de conteúdo simulada
- [x] Sistema de estilos
- [x] Seleção de IA
- [x] Exportação para TXT e PDF
- [x] Sistema premium
- [x] Armazenamento local
- [x] Base de dados Room

### 🔄 Para Implementação Futura
- [ ] Integração real com APIs de IA
- [ ] Exportação DOCX completa (Apache POI)
- [ ] Armazenamento em nuvem
- [ ] Sistema de pagamento real
- [ ] Notificações push
- [ ] Partilha de documentos

## Licença
Este projeto foi desenvolvido como demonstração técnica.

## Contacto
Para questões técnicas ou melhorias, contactar o desenvolvedor.

