package com.novaai.writer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.writer.ui.components.StyleSelector
import com.novaai.writer.ui.components.AISelector

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresentationScreen() {
    var subject by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Académico") }
    var selectedAI by remember { mutableStateOf("ChatGPT") }
    var isGenerating by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Criador de Apresentações",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Assunto da Apresentação",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Digite o assunto da sua apresentação") },
                    placeholder = { Text("Ex: Marketing Digital para Pequenas Empresas") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                StyleSelector(
                    selectedStyle = selectedStyle,
                    onStyleSelected = { selectedStyle = it }
                )

                AISelector(
                    selectedAI = selectedAI,
                    onAISelected = { selectedAI = it }
                )

                Button(
                    onClick = { 
                        if (subject.isNotBlank()) {
                            isGenerating = true
                            // TODO: Implementar geração de apresentação
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = subject.isNotBlank() && !isGenerating
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(if (isGenerating) "Gerando..." else "Gerar Apresentação")
                }
            }
        }

        if (isGenerating) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Gerando sua apresentação...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Isso pode levar alguns minutos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

