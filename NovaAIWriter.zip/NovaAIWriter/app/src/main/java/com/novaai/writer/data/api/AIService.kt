package com.novaai.writer.data.api

import com.novaai.writer.data.models.ContentRequest
import com.novaai.writer.data.models.ContentResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface AIService {
    @POST("generate/ebook")
    suspend fun generateEbook(@Body request: ContentRequest): Response<ContentResponse>
    
    @POST("generate/presentation")
    suspend fun generatePresentation(@Body request: ContentRequest): Response<ContentResponse>
    
    @POST("generate/document")
    suspend fun generateDocument(@Body request: ContentRequest): Response<ContentResponse>
}

