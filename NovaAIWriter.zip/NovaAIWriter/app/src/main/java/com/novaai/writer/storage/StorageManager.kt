package com.novaai.writer.storage

import android.content.Context
import androidx.room.Room
import com.google.gson.Gson
import com.novaai.writer.data.database.AppDatabase
import com.novaai.writer.data.database.SavedContentEntity
import com.novaai.writer.data.models.ContentResponse
import com.novaai.writer.data.models.Chapter
import com.novaai.writer.data.models.Slide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class StorageManager(private val context: Context) {
    
    private val database = Room.databaseBuilder(
        context,
        AppDatabase::class.java,
        "novaai_database"
    ).build()
    
    private val gson = Gson()
    
    suspend fun saveContent(content: ContentResponse): Result<Unit> {
        return withContext(Dispatchers.IO) {
            try {
                val entity = SavedContentEntity(
                    id = content.id,
                    title = content.title,
                    content = content.content,
                    contentType = content.contentType,
                    createdAt = content.createdAt,
                    chaptersJson = content.chapters?.let { gson.toJson(it) },
                    slidesJson = content.slides?.let { gson.toJson(it) }
                )
                
                database.savedContentDao().saveContent(entity)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
    
    suspend fun getAllSavedContent(): Result<List<ContentResponse>> {
        return withContext(Dispatchers.IO) {
            try {
                val entities = database.savedContentDao().getAllSavedContent()
                val contentList = entities.map { entity ->
                    ContentResponse(
                        id = entity.id,
                        title = entity.title,
                        content = entity.content,
                        contentType = entity.contentType,
                        createdAt = entity.createdAt,
                        chapters = entity.chaptersJson?.let { 
                            gson.fromJson(it, Array<Chapter>::class.java).toList() 
                        },
                        slides = entity.slidesJson?.let { 
                            gson.fromJson(it, Array<Slide>::class.java).toList() 
                        }
                    )
                }
                Result.success(contentList)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
    
    suspend fun getContentById(id: String): Result<ContentResponse?> {
        return withContext(Dispatchers.IO) {
            try {
                val entity = database.savedContentDao().getContentById(id)
                if (entity != null) {
                    val content = ContentResponse(
                        id = entity.id,
                        title = entity.title,
                        content = entity.content,
                        contentType = entity.contentType,
                        createdAt = entity.createdAt,
                        chapters = entity.chaptersJson?.let { 
                            gson.fromJson(it, Array<Chapter>::class.java).toList() 
                        },
                        slides = entity.slidesJson?.let { 
                            gson.fromJson(it, Array<Slide>::class.java).toList() 
                        }
                    )
                    Result.success(content)
                } else {
                    Result.success(null)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
    
    suspend fun deleteContent(id: String): Result<Unit> {
        return withContext(Dispatchers.IO) {
            try {
                database.savedContentDao().deleteContentById(id)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}

