package com.novaai.writer.data.repository

import com.novaai.writer.ai.AIProviderFactory
import com.novaai.writer.data.models.ContentRequest
import com.novaai.writer.data.models.ContentResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ContentRepository {
    
    suspend fun generateEbook(request: ContentRequest): Result<ContentResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val provider = AIProviderFactory.getProvider(request.aiProvider)
                val updatedRequest = request.copy(contentType = "ebook")
                provider.generateContent(updatedRequest)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
    
    suspend fun generatePresentation(request: ContentRequest): Result<ContentResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val provider = AIProviderFactory.getProvider(request.aiProvider)
                val updatedRequest = request.copy(contentType = "presentation")
                provider.generateContent(updatedRequest)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
    
    suspend fun generateDocument(request: ContentRequest): Result<ContentResponse> {
        return withContext(Dispatchers.IO) {
            try {
                val provider = AIProviderFactory.getProvider(request.aiProvider)
                val updatedRequest = request.copy(contentType = "document")
                provider.generateContent(updatedRequest)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}

