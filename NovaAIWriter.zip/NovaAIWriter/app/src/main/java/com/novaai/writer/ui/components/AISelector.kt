package com.novaai.writer.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AISelector(
    selectedAI: String,
    onAISelected: (String) -> Unit
) {
    val aiOptions = listOf("ChatGPT", "Claude", "Gemini", "Llama")

    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Inteligência Artificial",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium
        )

        aiOptions.forEach { ai ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = (ai == selectedAI),
                        onClick = { onAISelected(ai) }
                    )
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = (ai == selectedAI),
                    onClick = { onAISelected(ai) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = ai,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

