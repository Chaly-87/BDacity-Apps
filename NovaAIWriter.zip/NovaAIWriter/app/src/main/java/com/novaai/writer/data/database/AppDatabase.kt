package com.novaai.writer.data.database

import androidx.room.*
import com.novaai.writer.data.models.ContentResponse

@Entity(tableName = "saved_content")
data class SavedContentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val contentType: String,
    val createdAt: Long,
    val chaptersJson: String? = null,
    val slidesJson: String? = null
)

@Dao
interface SavedContentDao {
    @Query("SELECT * FROM saved_content ORDER BY createdAt DESC")
    suspend fun getAllSavedContent(): List<SavedContentEntity>
    
    @Query("SELECT * FROM saved_content WHERE id = :id")
    suspend fun getContentById(id: String): SavedContentEntity?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveContent(content: SavedContentEntity)
    
    @Delete
    suspend fun deleteContent(content: SavedContentEntity)
    
    @Query("DELETE FROM saved_content WHERE id = :id")
    suspend fun deleteContentById(id: String)
}

@Database(
    entities = [SavedContentEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedContentDao(): SavedContentDao
}

