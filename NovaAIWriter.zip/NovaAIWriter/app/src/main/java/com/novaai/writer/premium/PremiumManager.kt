package com.novaai.writer.premium

import android.content.Context
import android.content.SharedPreferences

class PremiumManager(context: Context) {
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences("premium_prefs", Context.MODE_PRIVATE)
    
    companion object {
        private const val KEY_IS_PREMIUM = "is_premium"
        private const val KEY_PREMIUM_EXPIRY = "premium_expiry"
        private const val KEY_DOCUMENTS_GENERATED_TODAY = "documents_generated_today"
        private const val KEY_LAST_GENERATION_DATE = "last_generation_date"
        
        // Limites para utilizadores gratuitos
        const val FREE_DAILY_LIMIT = 3
        const val FREE_CONTENT_MAX_LENGTH = 1000
        
        // Limites para utilizadores premium
        const val PREMIUM_DAILY_LIMIT = 50
        const val PREMIUM_CONTENT_MAX_LENGTH = 10000
    }
    
    fun isPremium(): Boolean {
        val isPremium = sharedPreferences.getBoolean(KEY_IS_PREMIUM, false)
        val expiryTime = sharedPreferences.getLong(KEY_PREMIUM_EXPIRY, 0)
        
        return if (isPremium && expiryTime > System.currentTimeMillis()) {
            true
        } else {
            // Se expirou, remover status premium
            if (isPremium && expiryTime <= System.currentTimeMillis()) {
                setPremiumStatus(false, 0)
            }
            false
        }
    }
    
    fun setPremiumStatus(isPremium: Boolean, expiryTimeMillis: Long) {
        sharedPreferences.edit()
            .putBoolean(KEY_IS_PREMIUM, isPremium)
            .putLong(KEY_PREMIUM_EXPIRY, expiryTimeMillis)
            .apply()
    }
    
    fun canGenerateContent(): Boolean {
        val today = getCurrentDateString()
        val lastGenerationDate = sharedPreferences.getString(KEY_LAST_GENERATION_DATE, "")
        val documentsGeneratedToday = if (lastGenerationDate == today) {
            sharedPreferences.getInt(KEY_DOCUMENTS_GENERATED_TODAY, 0)
        } else {
            0
        }
        
        val dailyLimit = if (isPremium()) PREMIUM_DAILY_LIMIT else FREE_DAILY_LIMIT
        return documentsGeneratedToday < dailyLimit
    }
    
    fun incrementGenerationCount() {
        val today = getCurrentDateString()
        val lastGenerationDate = sharedPreferences.getString(KEY_LAST_GENERATION_DATE, "")
        val documentsGeneratedToday = if (lastGenerationDate == today) {
            sharedPreferences.getInt(KEY_DOCUMENTS_GENERATED_TODAY, 0)
        } else {
            0
        }
        
        sharedPreferences.edit()
            .putInt(KEY_DOCUMENTS_GENERATED_TODAY, documentsGeneratedToday + 1)
            .putString(KEY_LAST_GENERATION_DATE, today)
            .apply()
    }
    
    fun getRemainingGenerations(): Int {
        val today = getCurrentDateString()
        val lastGenerationDate = sharedPreferences.getString(KEY_LAST_GENERATION_DATE, "")
        val documentsGeneratedToday = if (lastGenerationDate == today) {
            sharedPreferences.getInt(KEY_DOCUMENTS_GENERATED_TODAY, 0)
        } else {
            0
        }
        
        val dailyLimit = if (isPremium()) PREMIUM_DAILY_LIMIT else FREE_DAILY_LIMIT
        return maxOf(0, dailyLimit - documentsGeneratedToday)
    }
    
    fun getMaxContentLength(): Int {
        return if (isPremium()) PREMIUM_CONTENT_MAX_LENGTH else FREE_CONTENT_MAX_LENGTH
    }
    
    fun getAvailableExportFormats(): List<String> {
        return if (isPremium()) {
            listOf("PDF", "DOCX", "TXT")
        } else {
            listOf("TXT")
        }
    }
    
    fun canExportFormat(format: String): Boolean {
        return getAvailableExportFormats().contains(format.uppercase())
    }
    
    private fun getCurrentDateString(): String {
        val calendar = java.util.Calendar.getInstance()
        return "${calendar.get(java.util.Calendar.YEAR)}-${calendar.get(java.util.Calendar.MONTH)}-${calendar.get(java.util.Calendar.DAY_OF_MONTH)}"
    }
    
    // Método para simular upgrade para premium (em produção seria integrado com sistema de pagamento)
    fun simulateUpgradeToPremium() {
        val oneYearFromNow = System.currentTimeMillis() + (365L * 24 * 60 * 60 * 1000)
        setPremiumStatus(true, oneYearFromNow)
    }
}

