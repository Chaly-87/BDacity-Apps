package com.novaai.writer.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun DocumentTypeSelector(
    selectedType: String,
    onTypeSelected: (String) -> Unit
) {
    val documentTypes = listOf("Resumo", "Relatório", "Guia")

    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Tipo de Documento",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium
        )

        documentTypes.forEach { type ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = (type == selectedType),
                        onClick = { onTypeSelected(type) }
                    )
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = (type == selectedType),
                    onClick = { onTypeSelected(type) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = type,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

