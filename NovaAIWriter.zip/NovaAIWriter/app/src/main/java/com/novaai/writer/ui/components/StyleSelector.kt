package com.novaai.writer.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun StyleSelector(
    selectedStyle: String,
    onStyleSelected: (String) -> Unit
) {
    val styles = listOf("Académico", "Criativo", "Simples", "Técnico")

    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Estilo de Escrita",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium
        )

        styles.forEach { style ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = (style == selectedStyle),
                        onClick = { onStyleSelected(style) }
                    )
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = (style == selectedStyle),
                    onClick = { onStyleSelected(style) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = style,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

