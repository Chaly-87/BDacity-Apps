package com.novaai.writer.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaai.writer.data.models.ContentRequest
import com.novaai.writer.data.models.ContentResponse
import com.novaai.writer.data.repository.ContentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DocumentViewModel : ViewModel() {
    
    private val repository = ContentRepository()
    
    private val _uiState = MutableStateFlow(DocumentUiState())
    val uiState: StateFlow<DocumentUiState> = _uiState.asStateFlow()
    
    fun generateDocument(topic: String, documentType: String, style: String, aiProvider: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            
            val request = ContentRequest(
                topic = topic,
                style = style,
                aiProvider = aiProvider,
                contentType = "document",
                documentType = documentType
            )
            
            repository.generateDocument(request)
                .onSuccess { response ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        generatedContent = response,
                        error = null
                    )
                }
                .onFailure { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = exception.message ?: "Erro desconhecido"
                    )
                }
        }
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
    
    fun clearContent() {
        _uiState.value = _uiState.value.copy(generatedContent = null)
    }
}

data class DocumentUiState(
    val isLoading: Boolean = false,
    val generatedContent: ContentResponse? = null,
    val error: String? = null
)

