package com.novaai.writer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.writer.ui.components.StyleSelector
import com.novaai.writer.ui.components.AISelector
import com.novaai.writer.ui.components.DocumentTypeSelector

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScreen() {
    var topic by remember { mutableStateOf("") }
    var selectedDocumentType by remember { mutableStateOf("Resumo") }
    var selectedStyle by remember { mutableStateOf("Académico") }
    var selectedAI by remember { mutableStateOf("ChatGPT") }
    var isGenerating by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Gerador de Documentos Inteligentes",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                DocumentTypeSelector(
                    selectedType = selectedDocumentType,
                    onTypeSelected = { selectedDocumentType = it }
                )

                Text(
                    text = "Tema/Assunto",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Digite o tema do seu documento") },
                    placeholder = { Text("Ex: Sustentabilidade Empresarial") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                StyleSelector(
                    selectedStyle = selectedStyle,
                    onStyleSelected = { selectedStyle = it }
                )

                AISelector(
                    selectedAI = selectedAI,
                    onAISelected = { selectedAI = it }
                )

                Button(
                    onClick = { 
                        if (topic.isNotBlank()) {
                            isGenerating = true
                            // TODO: Implementar geração de documento
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = topic.isNotBlank() && !isGenerating
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(if (isGenerating) "Gerando..." else "Gerar Documento")
                }
            }
        }

        if (isGenerating) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Gerando seu documento...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Isso pode levar alguns minutos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

