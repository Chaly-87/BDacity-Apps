package com.novaai.writer.data.models

data class ContentRequest(
    val topic: String,
    val style: String,
    val aiProvider: String,
    val contentType: String, // "ebook", "presentation", "document"
    val documentType: String? = null // Para documentos: "resumo", "relatório", "guia"
)

data class ContentResponse(
    val id: String,
    val title: String,
    val content: String,
    val chapters: List<Chapter>? = null, // Para ebooks
    val slides: List<Slide>? = null, // Para apresentações
    val createdAt: Long,
    val contentType: String
)

data class Chapter(
    val title: String,
    val content: String,
    val order: Int
)

data class Slide(
    val title: String,
    val content: String,
    val order: Int
)

