package com.novaai.writer.exporter

import android.content.Context
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.novaai.writer.data.models.ContentResponse
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class DocumentExporter(private val context: Context) {
    
    fun exportToPDF(content: ContentResponse, fileName: String): Result<String> {
        return try {
            val file = File(context.getExternalFilesDir(null), "$fileName.pdf")
            val pdfWriter = PdfWriter(FileOutputStream(file))
            val pdfDocument = PdfDocument(pdfWriter)
            val document = Document(pdfDocument)
            
            // Adicionar título
            document.add(Paragraph(content.title).setFontSize(18f).setBold())
            document.add(Paragraph("\n"))
            
            // Adicionar conteúdo baseado no tipo
            when (content.contentType) {
                "ebook" -> {
                    content.chapters?.forEach { chapter ->
                        document.add(Paragraph(chapter.title).setFontSize(14f).setBold())
                        document.add(Paragraph(chapter.content))
                        document.add(Paragraph("\n"))
                    }
                }
                "presentation" -> {
                    content.slides?.forEach { slide ->
                        document.add(Paragraph(slide.title).setFontSize(14f).setBold())
                        document.add(Paragraph(slide.content))
                        document.add(Paragraph("\n"))
                    }
                }
                else -> {
                    document.add(Paragraph(content.content))
                }
            }
            
            document.close()
            Result.success(file.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun exportToTXT(content: ContentResponse, fileName: String): Result<String> {
        return try {
            val file = File(context.getExternalFilesDir(null), "$fileName.txt")
            val text = buildString {
                appendLine(content.title)
                appendLine("=" * content.title.length)
                appendLine()
                
                when (content.contentType) {
                    "ebook" -> {
                        content.chapters?.forEach { chapter ->
                            appendLine(chapter.title)
                            appendLine("-" * chapter.title.length)
                            appendLine(chapter.content)
                            appendLine()
                        }
                    }
                    "presentation" -> {
                        content.slides?.forEach { slide ->
                            appendLine("SLIDE ${slide.order}: ${slide.title}")
                            appendLine("-" * (slide.title.length + 10))
                            appendLine(slide.content)
                            appendLine()
                        }
                    }
                    else -> {
                        appendLine(content.content)
                    }
                }
            }
            
            file.writeText(text)
            Result.success(file.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun exportToDOCX(content: ContentResponse, fileName: String): Result<String> {
        // Para uma implementação completa, seria necessário usar Apache POI
        // Por agora, vamos usar uma implementação simplificada que salva como TXT
        return exportToTXT(content, fileName)
    }
    
    private operator fun String.times(n: Int): String = this.repeat(n)
}

